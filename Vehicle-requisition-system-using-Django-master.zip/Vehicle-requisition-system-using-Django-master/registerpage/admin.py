from django.contrib import admin
from registerpage.models import CarData,RentData

admin.site.register(CarData)
admin.site.register(RentData)

