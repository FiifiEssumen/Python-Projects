from django.apps import AppConfig


class RegisterpageConfig(AppConfig):
    name = 'registerpage'
