# Vehicle-requisition-system-using-Django
this is a simple project based on online car rental system  using python(Django), html,CSS, bootstrap.
